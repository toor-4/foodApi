# docker compose start

<!---MARKER_GEN_START-->
Start services

### Options

| Name        | Type | Default | Description                     |
|:------------|:-----|:--------|:--------------------------------|
| `--dry-run` |      |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->

## Description

Starts existing containers for a service.
