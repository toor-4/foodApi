# docker compose alpha publish

<!---MARKER_GEN_START-->
Publish compose application

### Options

| Name                      | Type | Default | Description                     |
|:--------------------------|:-----|:--------|:--------------------------------|
| `--dry-run`               |      |         | Execute command in dry run mode |
| `--resolve-image-digests` |      |         | Pin image tags to digests.      |


<!---MARKER_GEN_END-->

