# docker compose unpause

<!---MARKER_GEN_START-->
Unpause services

### Options

| Name        | Type | Default | Description                     |
|:------------|:-----|:--------|:--------------------------------|
| `--dry-run` |      |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->

## Description

Unpauses paused containers of a service.
